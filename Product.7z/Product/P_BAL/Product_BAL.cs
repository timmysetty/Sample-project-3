﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using P_Entity;
using P_Exception;
using P_DAL;
using System.Data.SqlClient;

namespace P_BAL
{
    public class Product_BAL
    {
        public bool ValidateProduct(Product pro)
        {
            bool isValidpatient = true;
            StringBuilder sbPMSError = new StringBuilder();


            if (pro.ProductId < 0)
            {
                isValidpatient = false;
                sbPMSError.Append("Id not " + Environment.NewLine);
            }
            if (pro.ProductName.Length == 0)
            {
                isValidpatient = false;
                sbPMSError.Append(" Name not " + Environment.NewLine);
            }
            if (pro.Description.Length == 0)
            {
                isValidpatient = false;
                sbPMSError.Append("price not " + Environment.NewLine);
            }
            if (pro.UnitPrice < 0)
            {
                isValidpatient = false;
                sbPMSError.Append("patient Name must have only characters starting with uppercase " + Environment.NewLine);
            }

            if (!isValidpatient)

            { throw new ProductException(sbPMSError.ToString()); }

            return isValidpatient;



        }

        public void AddProductBAL(Product pro)
        {
            try
            {

                if (ValidateProduct(pro))
                {
                    Product_DAL pd = new Product_DAL();
                    pd.AddProductDAL(pro);
                }
                else
                {
                    throw new ProductException("Failed to Add Product");
                }

            }

            catch (ProductException)
            {
                throw;
            }

        }

        public static Product SearchProductBL(int searchPatientID)
        {
            Product searchProduct = null;
            try
            {
                Product_DAL productDAL = new Product_DAL();
                searchProduct = productDAL.SearchProductDAL(searchPatientID);
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchProduct;

        }

        public static bool UpdateProductBL(Product productID)
        {
            bool UpdatedProduct;
            try
            {

                Product_DAL patientDAL = new Product_DAL();
                UpdatedProduct = patientDAL.UpdateProductDAL(productID);

            }
            catch (ProductException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return UpdatedProduct;
        }

        public DataTable DisplayProductBLL()
        {
            Product_DAL st = new Product_DAL();
            DataTable dtpatient = st.DisplayProductDAL();

            try
            {

                if (dtpatient == null)
                {
                    throw new ProductException("No Product Available");
                }

            }
            catch (ProductException pe)
            {
                throw pe;

            }
            catch (SqlException se)
            {

                throw se;
            }
            return dtpatient;
        }

        public int DeleteProductBAL(int productID)
        {

            Product_DAL del = new Product_DAL();
            int delete = del.DeleteProductDAl(productID);
            return delete;
        }
    }
}
