﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using P_BAL;
using P_Exception;
using P_Entity;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace p_pl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        static string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        SqlConnection con = new SqlConnection(conStr);
        SqlCommand cmd = new SqlCommand();
        
       
       


        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product_BAL st = new Product_BAL();
                DataTable dt = st.DisplayProductBLL();




                dt_Display.ItemsSource = dt.DefaultView;



            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            //finally
            //{

            //}
        }

        private void btn_Upadate_Click(object sender, RoutedEventArgs e)
        {
            //int ProductID = int.Parse(txt_Pid.Text);

            //bool SearchedProduct = UpdateProductByID(ProductID);
            try
            {

                Product p = new Product();
                {
                    p.ProductId = int.Parse(txt_Pid.Text);
                    p.ProductName = txt_Pname.Text;
                    p.Description = txt_Desc.Text;
                    p.UnitPrice = decimal.Parse(txt_Price.Text);

                };

                UpdateProductByID(p);
                MessageBox.Show(string.Format("Product Updated", "Product Management System"));
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }


        }

        private bool UpdateProductByID(Product p)
        {
            bool UpdateProduct = false;
            try
            {
                UpdateProduct = Product_BAL.UpdateProductBL(p);
            }
            catch (ProductException ex)
            {

                MessageBox.Show(ex.Message);
            }
            return UpdateProduct;
        }

        

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con.ConnectionString = conStr;
            //executing cmd for auto incremented ID
            cmd = new SqlCommand("select ident_current('Auto_172324') + ident_incr('Auto_172324')", con);
            con.Open();
            object nxId = cmd.ExecuteScalar();   //storing the auto incremented ID 
            txt_Name.Text = nxId.ToString();
        }

        private void Btn_Insert_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                Product p = new Product();
                {
                    p.ProductId = int.Parse(txt_Pid.Text);
                    p.ProductName = txt_Pname.Text;
                    p.Description = txt_Desc.Text;
                    p.UnitPrice = decimal.Parse(txt_Price.Text);

                };
                Product_BAL pb = new Product_BAL();
                pb.AddProductBAL(p);
                MessageBox.Show(string.Format("New Product Added", "Product Management System"));
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void Btn_Search_Click_1(object sender, RoutedEventArgs e)
        {
            int ProductID = int.Parse(txt_Pid.Text);
            Product SearchedProduct = SearchProductByID(ProductID);
            txt_Pname.Text = SearchedProduct.ProductName;
            txt_Desc.Text = SearchedProduct.Description;
            txt_Price.Text = SearchedProduct.UnitPrice.ToString();

        }
        private static Product SearchProductByID(int ProductID)
        {
            Product searchProductID = new Product();
            try
            {
                searchProductID = Product_BAL.SearchProductBL(ProductID);
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return searchProductID;
        }

        private void Btn_Delete_Click_1(object sender, RoutedEventArgs e)
        {
            int ProductID = int.Parse(txt_Pid.Text);
            try
            {

                Product_BAL del = new Product_BAL();
                int dell = del.DeleteProductBAL(ProductID);
                if (dell == 1)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Available");
                }
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }
    }
}


