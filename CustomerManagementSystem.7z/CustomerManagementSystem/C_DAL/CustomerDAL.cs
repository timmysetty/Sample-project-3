﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_Entity;
using C_Exception;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace C_DAL
{
    public class CustomerDAL
    {
        static string conStr = string.Empty;

        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();



        static CustomerDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public CustomerDAL()
        {
            con = new SqlConnection(conStr);

        }

        public void AddCustomerDAL(Customer cus)
        {
            //int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand("addCustomer1_172282", con);

                //cmd.CommandText = "Nepun.udp_insert_patientDetails";
                //cmd.Connection = con;

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@CustomerId", cus.CustomerId);
                cmd.Parameters.AddWithValue("@CustomerName", cus.CustomerName);
                cmd.Parameters.AddWithValue("@Address", cus.Address);
                cmd.Parameters.AddWithValue("@Gender", cus.Gender);
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (CustomerException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            //return pid;
        }

        public Customer SearchCustomerDAL(int searchCustomerID)
        {
            Customer SearchedCustomer = new Customer();
            try
            {
                con.ConnectionString = conStr;
                con.Open();
                //SqlCommand Command = new SqlCommand();
                cmd.Connection = con;
                string query = "searchCustomer1_172282";
                cmd.Parameters.AddWithValue("@CustomerId", searchCustomerID);
                cmd.CommandText = query;

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = cmd.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        SearchedCustomer.CustomerId = int.Parse(Reader[0].ToString());
                        SearchedCustomer.CustomerName = Reader[1].ToString();
                        SearchedCustomer.Address = Reader[2].ToString();
                        SearchedCustomer.Gender = Reader[3].ToString();
                    }
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            return SearchedCustomer;
        }

        public DataTable DisplayCustomerDAL()
        {
            DataTable dt = null;
            try
            {
                cmd = new SqlCommand("DisplayCustomer1_172282", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }


            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;

            }

            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return dt;
        }

        public int DeleteCustomerDAl(int customerID)
        {
            try
            {
                cmd = new SqlCommand("DeleteCustomer1_172282", con);
                cmd.Parameters.AddWithValue("@CustomerId", customerID);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                int NumberOfRowsAdded = cmd.ExecuteNonQuery();
                return NumberOfRowsAdded;
            }
            catch (CustomerException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public bool UpdateCustomerDAL(Customer customerID)
        {
            Customer up = new Customer();
            up = customerID;
            try
            {
                cmd = new SqlCommand("UpdateCustomer1_172282", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustomerId", up.CustomerId);
                cmd.Parameters.AddWithValue("@CustomerName", up.CustomerName);
                cmd.Parameters.AddWithValue("@Address", up.Address);
                cmd.Parameters.AddWithValue("@Gender", up.Gender);
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();              
            }
            catch (CustomerException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return true;


        }
    }
}
