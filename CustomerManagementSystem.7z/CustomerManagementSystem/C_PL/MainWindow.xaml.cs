﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C_Entity;
using C_Exception;
using C_BAL;
using System.Data;

namespace C_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        static string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        SqlConnection con = new SqlConnection(conStr);
        SqlCommand cmd = new SqlCommand();



        private void Btn_Insert_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                Customer p = new Customer();
                {
                    p.CustomerId = int.Parse(txt_Pid.Text);
                    p.CustomerName = txt_Pname.Text;
                    p.Address = txt_Desc.Text;
                    p.Gender = (txt_Price.Text);

                };
                CustomerBAL pb = new CustomerBAL();
                pb.AddProductBAL(p);
                MessageBox.Show(string.Format("New Customer Added", "Customer Management System"));
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message, "Customer Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Customer Management System");
            }
        }

        private void Btn_Search_Click_1(object sender, RoutedEventArgs e)
        {
            int ProductID = int.Parse(txt_Pid.Text);
            Customer SearchedCustomer = SearchProductByID(ProductID);
            txt_Pname.Text = SearchedCustomer.CustomerName;
            txt_Desc.Text = SearchedCustomer.Address;
            txt_Price.Text = SearchedCustomer.Gender.ToString();

        }
        private static Customer SearchProductByID(int CustomerId)
        {
            Customer searchProductID = new Customer();
            try
            {
                searchProductID = CustomerBAL.searchCustomerBL(CustomerId);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return searchProductID;
        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CustomerBAL st = new CustomerBAL();
                DataTable dt = st.DisplayCustomerBLL();




                dt_Display.ItemsSource = dt.DefaultView;



            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message, "Customer Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
        }

        private void Btn_Delete_Click_1(object sender, RoutedEventArgs e)
        {
            int ProductID = int.Parse(txt_Pid.Text);
            try
            {

                CustomerBAL del = new CustomerBAL();
                int dell = del.DeleteCustomerBAL(ProductID);
                if (dell == 1)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Available");
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message, "Customer Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Customer Management System");
            }
        }

        private void btn_Upadate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Customer p = new Customer();
                {
                    p.CustomerId = int.Parse(txt_Pid.Text);
                    p.CustomerName = txt_Pname.Text;
                    p.Address = txt_Desc.Text;
                    p.Gender = (txt_Price.Text);

                };

                UpdatecustomerByID(p);
                MessageBox.Show(string.Format("Customer Updated", "Customer Management System"));
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message, "customer Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "customer Management System");
            }


        }

        private bool UpdatecustomerByID(Customer p)
        {
            bool UpdateCustomer = false;
            try
            {
                UpdateCustomer = CustomerBAL.UpdateCustomertBL(p);
            }
            catch (CustomerException ex)
            {

                MessageBox.Show(ex.Message);
            }
            return UpdateCustomer;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con.ConnectionString = conStr;
            //executing cmd for auto incremented ID
            cmd = new SqlCommand("select ident_current('Auto_172324') + ident_incr('Auto_172324')", con);
            con.Open();
            object nxId = cmd.ExecuteScalar();   //storing the auto incremented ID 
            txt_Name.Text = nxId.ToString();
        }

       
    }
}
