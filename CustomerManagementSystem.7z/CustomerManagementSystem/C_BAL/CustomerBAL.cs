﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C_DAL;
using C_Entity;
using C_Exception;

namespace C_BAL
{
    public class CustomerBAL
    {
        public bool ValidateProduct(Customer pro)
        {
            bool isValidpatient = true;
            StringBuilder sbPMSError = new StringBuilder();


            if (pro.CustomerId < 0)
            {
                isValidpatient = false;
                sbPMSError.Append("Id not " + Environment.NewLine);
            }
            if (pro.CustomerName.Length == 0)
            {
                isValidpatient = false;
                sbPMSError.Append(" Name not " + Environment.NewLine);
            }
            if (pro.Address.Length == 0)
            {
                isValidpatient = false;
                sbPMSError.Append("Address not " + Environment.NewLine);
            }
            if (pro.Gender.Length==0)
            {
                isValidpatient = false;
                sbPMSError.Append("Customer Name must have only characters starting with uppercase " + Environment.NewLine);
            }

            if (!isValidpatient)

            { throw new CustomerException(sbPMSError.ToString()); }

            return isValidpatient;



        }

        public void AddProductBAL(Customer pro)
        {
            try
            {

                if (ValidateProduct(pro))
                {
                    CustomerDAL pd = new CustomerDAL();
                    pd.AddCustomerDAL(pro);
                }
                else
                {
                    throw new CustomerException("Failed to Add Customer");
                }

            }

            catch (CustomerException)
            {
                throw;
            }

        }

        public static Customer searchCustomerBL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                searchCustomer = customerDAL.SearchCustomerDAL(searchCustomerID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCustomer;

        }

        public static bool UpdateCustomertBL(Customer CustomerID)
        {
            bool UpdatedCustomer;
            try
            {

                CustomerDAL customerDAL = new CustomerDAL();
                UpdatedCustomer = customerDAL.UpdateCustomerDAL(CustomerID);

            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return UpdatedCustomer;
        }

        public DataTable DisplayCustomerBLL()
        {
            CustomerDAL st = new CustomerDAL();
            DataTable dtcust = st.DisplayCustomerDAL();

            try
            {

                if (dtcust == null)
                {
                    throw new CustomerException("No Customer Available");
                }

            }
            catch (CustomerException pe)
            {
                throw pe;

            }
            catch (SqlException se)
            {

                throw se;
            }
            return dtcust;
        }

        public int DeleteCustomerBAL(int customerID)
        {

            CustomerDAL del = new CustomerDAL();
            int delete = del.DeleteCustomerDAl(customerID);
            return delete;
        }
    }
}
